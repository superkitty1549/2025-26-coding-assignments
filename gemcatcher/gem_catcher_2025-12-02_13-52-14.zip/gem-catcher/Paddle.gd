extends Area2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.

var movement: float = Input.get_axis("move.left", "move.right")
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	
	
	if Input.is_action_pressed("move.right")==true:
		position.x += 2000 * delta
	if Input.is_action_pressed("move.left")==true:
		position.x -= 2000 * delta
	position.x = clampf(
	position.x, 
	get_viewport_rect().position.x,
	get_viewport_rect().end.x,
)		
