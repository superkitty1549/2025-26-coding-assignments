extends Node2D

class_name Game

const GEM = preload("res://SCENES/GAME/GAME.tscn")


func _on_paddle_area_entered(area: Area2D) -> void:
	print("Game:: collision ", area)


func _on_gem_gem_off_screen() -> void:
	print("Game:: _on_gem_off_screen")
