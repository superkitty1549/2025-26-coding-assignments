extends Area2D
const SPEED: float = 360.0

func _process(delta: float) -> void:
	var movement:float = Input.get_axis("move_left", "move_right")
	position.x += SPEED * delta * movement
	
	position.x =clampf(
		position.x,
		get_viewport_rect().position.x,
		get_viewport_rect().end.x
	)

func _on_area_entered(_area) -> void:
	print("_on_area_entered from Paddle definition")
	
