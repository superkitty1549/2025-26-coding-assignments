extends Area2D

class_name Gem

signal gem_off_screen

const SPEED: float = 200.0

func _process(delta: float) -> void:
	position .y += SPEED * delta
	
	if position.y > get_viewport_rect().end.y:
		print("Gem falls off")
		gem_off_screen.emit()
		die()
		
func die() -> void:
	queue_free()
	
func _on_area_entered(_area: Area2D) -> void:
	queue_free()
	
